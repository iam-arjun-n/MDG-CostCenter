sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("com.deloitte.mdg.cost.center.costcenter.controller.Overview", {
        onInit() {
        }
    });
});